(function($, elementor) {
    'use strict';
    var widgetImageAccordion = function($scope, $) {
        var $imageAccordion = $scope.find('.first-sample ');

        if (!$imageAccordion.length) {
            return;
        }

        elementorFrontend.waypoint($imageAccordion, function() {

            var $this = $(this);
            var $settings = $this.data('settings');

            var $sliderMain = $('#' + $settings.id + ' .slider');

            $($sliderMain).blue_slider({
                slide_template: '1fr 1fr 7fr (3,1fr) 1fr',
                current_fr_index: 3,
                current_fr_index_flow: false,
                current_fr_class: 'my-fr-current',
                active_fr_class: 'my-fr-active',
                custom_fr_class: '       fr-1         fr-2        fr-3    ',
                sencitive_drag: 100,
                start_slide_index: 0,
                arrows: true,
                prev_arrow: '#' + $settings.id + ' .prev-slide',
                next_arrow: '#' + $settings.id + ' .next-slide',

                slide_gap: $settings.slide_gap,
                auto_play_period: $settings.auto_play_period,
                ease_function: $settings.ease_function,
                auto_play: $settings.auto_play,
                loop: $settings.loop

            });

        });
    };

    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-image-accordion.default', widgetImageAccordion);
    });

}(jQuery, window.elementorFrontend));