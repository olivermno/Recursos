(function($, elementor) {
    'use strict';
    // PostGallery
    var widgetPostGallery = function($scope, $) {
        function hashHandler() {
            if (window.location.hash) {
                // $('[bdt-filter-control="[data-filter*=\'bdtf-' + window.location.hash.substring(1) + '\']"]').trigger("click");
                if ($('[data-filter*="bdtf-' + window.location.hash.substring(1) + '"]').length > 0) {
 
                    $('html').animate({
                        easing: 'slow',
                        scrollTop: $('[data-filter*="bdtf-' + window.location.hash.substring(1) + '"]').offset().top,
                    }, 1500, function() {
                        $('[bdt-filter-control="[data-filter*=\'bdtf-' + window.location.hash.substring(1) + '\']"]').trigger("click");
                    });
                    
                }
            }
        }
        $(window).on('load', function() {
            hashHandler();
        });
        $('.bdt-ep-grid-filter').on('click', function() {
            window.location.hash = ($.trim($(this).context.innerText.toLowerCase())).replace(/\s+/g, '-');
        });
        window.addEventListener("hashchange", hashHandler, true);
    };
    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-faq.default', widgetPostGallery);
    });
}(jQuery, window.elementorFrontend));