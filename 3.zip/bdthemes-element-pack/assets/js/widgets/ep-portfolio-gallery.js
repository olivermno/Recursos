(function($, elementor) {
    'use strict';
    // PortfolioGallery
    var widgetPortfolioGallery = function($scope, $) {
        function hashHandler() {
            if (window.location.hash) {
                if ($('[bdt-filter-control="[data-filter*=\'bdtp-' + window.location.hash.substring(1) + '\']"]').length > 0) {
                    $('html, body').animate({
                        easing: 'slow',
                        scrollTop: $('.bdt-portfolio-gallery-wrapper').offset().top,
                    }, 1500, function() {
                        $('[bdt-filter-control="[data-filter*=\'bdtp-' + window.location.hash.substring(1) + '\']"]').trigger("click");
                    });
                }
            }
        }
        $(window).on('load', function() {
            hashHandler();
        });
        $('.bdt-ep-grid-filter').on('click', function() {
            // window.location.hash = ('bdtp-'+($.trim($(this).context.innerText.toLowerCase()))).replace(/\s+/g, '-'); // backup
            window.location.hash = ($.trim($(this).context.innerText.toLowerCase())).replace(/\s+/g, '-');
        });
        window.addEventListener("hashchange", hashHandler, true);
    };
    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-portfolio-gallery.default', widgetPortfolioGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-portfolio-gallery.bdt-abetis', widgetPortfolioGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-portfolio-gallery.bdt-fedara', widgetPortfolioGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-portfolio-gallery.bdt-trosia', widgetPortfolioGallery);
    });
}(jQuery, window.elementorFrontend)); 