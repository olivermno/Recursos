( function( $, elementor ) {

	'use strict';

	var widgetToggle = function( $scope, $ ) {

		var $toggle = $scope.find( '.bdt-show-hide-container' );
				
        if ( ! $toggle.length ) {
            return;
        }

        (function($) {
            $(".bdt-show-hide-title").unbind("click").on("click", function(event) {
                event.preventDefault();
                var hash = $(this).attr('href');
                if (hash !== "") {
                    console.log(hash);
                    $(hash).parent().attr('id', hash.substr(1) + '-parent');
                    var hashParent = hash + '-parent';
                    $("html, body")
                        .animate({
                            scrollTop: $(hashParent).offset().top - 10
                        }, 800, function() {
                            /* Called per el */
                        }).promise().then(function() {
                            $(hash).slideToggle("slow", function() {
                                $(hashParent).toggleClass("bdt-open");
                            });

                        });
                }
                // return false;
            });
        })(jQuery);

	};
 

	jQuery(window).on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/bdt-toggle.default', widgetToggle );
	});

}( jQuery, window.elementorFrontend ) );
