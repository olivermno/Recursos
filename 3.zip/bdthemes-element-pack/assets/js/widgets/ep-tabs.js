(function($, elementor) {
    'use strict';
    var widgetTabs = function($scope, $) {
        var $tabs = $scope.find('.bdt-tabs'),
            $tab = $tabs.find('.bdt-tab');
        if (!$tabs.length) {
            return;
        }
        var tabID = $(location.hash);
        if (tabID.length > 0 && tabID.hasClass('bdt-tabs-item-title')) {
            $('html').animate({
                easing: 'slow',
                scrollTop: tabID.offset().top
            }, 1500, function() {
                bdtUIkit.tab($tab).show($(tabID).data('tab-index'));
            });
        }
        // start by si
        function hashHandler($tab) {
            if (window.location.hash) {
                if ($('[data-title="' + window.location.hash.substring(1) + '"]').length > 0) {
                    $('html, body').animate({
                        scrollTop: $('[data-title="' + window.location.hash.substring(1) + '"]').offset().top
                    }, 1500, function() {
                        bdtUIkit.tab($tab).show($('[data-title="' + window.location.hash.substring(1) + '"]').data('tab-index'));
                    });
                }
            }
        }
        $(window).on('load', function() {
            hashHandler($tab);
        });
        $('.bdt-tabs-item-title').on('click', function(event) {
            window.location.hash = ($.trim($(this).attr('data-title')));
        });
        // window.addEventListener("hashchange", test, true); // this not fixed finally
        // end by si
    };
    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-tabs.default', widgetTabs);
    });
}(jQuery, window.elementorFrontend));