(function($, elementor) {
    'use strict';
    // Accordion
    var widgetAccordion = function($scope, $) {
        var $accordion = $scope.find('.bdt-accordion');
        if (!$accordion.length) {
            return;
        }
        var acdID = $(location.hash);
        if (acdID.length > 0 && acdID.hasClass('bdt-accordion-title')) {
            $('html').animate({
                easing: 'slow',
                scrollTop: acdID.offset().top,
            }, 1500, function() {
                bdtUIkit.accordion($accordion).toggle($(acdID).data('accordion-index'), true);
            });
        }
        // start by si
        function hashHandler($accordion) {
            if (window.location.hash) {
                if ($('[data-title="' + window.location.hash.substring(1) + '"]').length > 0) {
                    $('html').animate({
                        easing: 'slow',
                        scrollTop: $('[data-title="' + window.location.hash.substring(1) + '"]').offset().top,
                    }, 1500, function() {
                        bdtUIkit.accordion($accordion).toggle($('[data-title="' + window.location.hash.substring(1) + '"]').data('accordion-index'), true);
                    });
                }
            }
        }
        $(window).on('load', function() {
            hashHandler($accordion);
        });
        $('.bdt-accordion-title').on('click', function(event) {
            window.location.hash = ($.trim($(this).attr('data-title')));
        });
        // window.addEventListener("hashchange", test, true); // this not fixed finally
        // end by si
    };
    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-accordion.default', widgetAccordion);
    });
}(jQuery, window.elementorFrontend)); 