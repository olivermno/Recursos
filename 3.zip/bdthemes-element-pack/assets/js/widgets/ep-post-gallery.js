(function($, elementor) {
    'use strict';
    // PostGallery
    var widgetPostGallery = function($scope, $) {
        function hashHandler() {
            if (window.location.hash) {
                if ($('[bdt-filter-control="[data-filter*=\'' + window.location.hash.substring(1) + '\']"]').length > 0) {
                    $('html, body').animate({
                        easing: 'slow',
                        // scrollTop: $('[bdt-filter-control="[data-filter*=\'' + window.location.hash.substring(1) + '\']"]').offset().top,
                        scrollTop: $('.bdt-post-gallery-wrapper').offset().top,
                    }, 1500, function() {
                        $('[bdt-filter-control="[data-filter*=\'' + window.location.hash.substring(1) + '\']"]').trigger("click");
                    });
                }
            }
        }
        $(window).on('load', function() {
            hashHandler();
        });
        $('.bdt-ep-grid-filter').on('click', function() {
            window.location.hash = ($.trim($(this).context.innerText.toLowerCase())).replace(/\s+/g, '-');
        });
        window.addEventListener("hashchange", hashHandler, true);
    };
    jQuery(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-post-gallery.default', widgetPostGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-post-gallery.bdt-abetis', widgetPostGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-post-gallery.bdt-fedara', widgetPostGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/bdt-post-gallery.bdt-trosia', widgetPostGallery);
    });
}(jQuery, window.elementorFrontend)); 